import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Building2, PlayCircle, BookOpen, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Resource {
  id: string;
  title: string;
  description: string;
  video_url: string;
  guide_content: string;
}

interface Company {
  id: string;
  name: string;
  logo_url: string;
}

export default function CompanyResources() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [company, setCompany] = useState<Company | null>(null);
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'videos' | 'guides'>('videos');

  useEffect(() => {
    fetchCompanyAndResources();
  }, [id]);

  const fetchCompanyAndResources = async () => {
    try {
      const [companyResponse, resourcesResponse] = await Promise.all([
        supabase.from('companies').select('*').eq('id', id).single(),
        supabase.from('interview_resources').select('*').eq('company_id', id),
      ]);

      if (companyResponse.error) throw companyResponse.error;
      if (resourcesResponse.error) throw resourcesResponse.error;

      setCompany(companyResponse.data);
      setResources(resourcesResponse.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderVideoContent = (resource: Resource) => (
    <div className="aspect-w-16 aspect-h-9 mb-6">
      <div className="relative rounded-lg overflow-hidden">
        <iframe
          src={resource.video_url}
          title={resource.title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="w-full h-[400px] rounded-lg"
        />
      </div>
      <div className="mt-4">
        <h3 className="text-xl font-semibold text-gray-900">{resource.title}</h3>
        <p className="mt-2 text-gray-600">{resource.description}</p>
      </div>
    </div>
  );

  const renderGuideContent = (resource: Resource) => (
    <div className="prose max-w-none mb-8">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">{resource.title}</h3>
        <div className="markdown-content whitespace-pre-wrap">
          {resource.guide_content.split('\n').map((line, index) => {
            if (line.startsWith('# ')) {
              return <h1 key={index} className="text-2xl font-bold mt-6 mb-4">{line.slice(2)}</h1>;
            } else if (line.startsWith('## ')) {
              return <h2 key={index} className="text-xl font-semibold mt-5 mb-3">{line.slice(3)}</h2>;
            } else if (line.startsWith('### ')) {
              return <h3 key={index} className="text-lg font-medium mt-4 mb-2">{line.slice(4)}</h3>;
            } else if (line.startsWith('- ')) {
              return <li key={index} className="ml-4">{line.slice(2)}</li>;
            } else if (line.startsWith('**')) {
              const text = line.replace(/\*\*/g, '');
              return <strong key={index} className="font-semibold">{text}</strong>;
            } else {
              return <p key={index} className="my-2">{line}</p>;
            }
          })}
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!company) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl text-gray-600">Company not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-start h-16">
            <button
              onClick={() => navigate('/companies')}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back to Companies
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="flex items-center mb-8">
            {company.logo_url ? (
              <img
                src={company.logo_url}
                alt={company.name}
                className="h-16 w-16 object-contain rounded-lg"
              />
            ) : (
              <Building2 className="h-16 w-16 text-gray-400" />
            )}
            <h1 className="ml-4 text-3xl font-bold text-gray-900">
              {company.name} Interview Preparation
            </h1>
          </div>

          <div className="mb-8">
            <div className="border-b border-gray-200">
              <nav className="-mb-px flex space-x-8">
                <button
                  onClick={() => setActiveTab('videos')}
                  className={`${
                    activeTab === 'videos'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } flex items-center whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                >
                  <PlayCircle className="h-5 w-5 mr-2" />
                  Video Tutorials
                </button>
                <button
                  onClick={() => setActiveTab('guides')}
                  className={`${
                    activeTab === 'guides'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } flex items-center whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                >
                  <BookOpen className="h-5 w-5 mr-2" />
                  Preparation Guides
                </button>
              </nav>
            </div>
          </div>

          <div className="space-y-8">
            {resources.map((resource) => (
              <div key={resource.id}>
                {activeTab === 'videos' && resource.video_url && renderVideoContent(resource)}
                {activeTab === 'guides' && resource.guide_content && renderGuideContent(resource)}
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}