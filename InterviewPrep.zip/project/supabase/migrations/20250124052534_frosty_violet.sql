/*
  # Add detailed interview resources

  1. Updates
    - Add company-specific interview questions and answers
    - Include real video tutorial links
    - Add comprehensive preparation guides
*/

-- Delete existing resources to avoid duplicates
DELETE FROM interview_resources;

-- Google Resources
INSERT INTO interview_resources (company_id, title, description, video_url, guide_content)
SELECT 
  id,
  'Google Technical Interview Guide',
  'Complete preparation guide for Google technical interviews',
  'https://www.youtube.com/embed/XKu_SEDAykw',
  E'# Google Interview Guide\n\n## Common Interview Questions\n\n### Data Structures & Algorithms\n1. **Question**: Implement a LRU Cache\n   **Answer**: Use a hashmap and doubly linked list for O(1) operations\n\n2. **Question**: Find the longest substring without repeating characters\n   **Answer**: Use sliding window technique with a hashmap\n\n### System Design\n1. **Question**: Design Google Search\n   **Key Points**:\n   - Web crawler architecture\n   - PageRank algorithm\n   - Query processing\n   - Indexing system\n\n### Behavioral Questions\n1. **Question**: Tell me about a time you handled a challenging situation\n   **Approach**: Use STAR method (Situation, Task, Action, Result)\n\n## Interview Process\n1. Phone Screen\n2. Technical Rounds\n3. Team Match\n\n## Preparation Resources\n- LeetCode Premium\n- System Design Primer\n- Google Tech Dev Guide'
FROM companies WHERE name = 'Google';

-- Microsoft Resources
INSERT INTO interview_resources (company_id, title, description, video_url, guide_content)
SELECT 
  id,
  'Microsoft Interview Preparation',
  'Essential guide for Microsoft interviews',
  'https://www.youtube.com/embed/7UlslIXHNsw',
  E'# Microsoft Interview Guide\n\n## Technical Questions\n\n### Coding\n1. **Question**: Implement a Binary Tree Serialization\n   **Answer**: Use preorder traversal with null markers\n\n2. **Question**: Design an elevator system\n   **Answer**: Use state pattern with priority queue\n\n### System Design\n1. **Question**: Design Microsoft Teams\n   **Key Components**:\n   - Real-time messaging\n   - Video conferencing\n   - File sharing\n   - Authentication\n\n### Behavioral\n1. **Question**: Describe a project where you demonstrated leadership\n   **Framework**: Focus on impact and collaboration\n\n## Interview Rounds\n1. Initial Screen\n2. Coding Rounds\n3. System Design\n4. Behavioral\n\n## Study Materials\n- Azure Documentation\n- Design Patterns\n- Distributed Systems'
FROM companies WHERE name = 'Microsoft';

-- Amazon Resources
INSERT INTO interview_resources (company_id, title, description, video_url, guide_content)
SELECT 
  id,
  'Amazon Interview Guide',
  'Leadership Principles and Technical Preparation',
  'https://www.youtube.com/embed/mjZpZ_wcYFg',
  E'# Amazon Interview Guide\n\n## Leadership Principles Questions\n\n1. **Customer Obsession**\n   **Question**: Tell me about a time you went above and beyond for a customer\n   **Answer Framework**: Situation, Action, Impact on Customer\n\n2. **Ownership**\n   **Question**: Describe a time you took on something significant outside your area of responsibility\n   **Response Structure**: Challenge, Action, Result\n\n## Technical Questions\n\n### Coding\n1. **Question**: Design a warehouse management system\n   **Key Points**: Optimization, Efficiency, Scalability\n\n2. **Question**: Implement a shopping cart system\n   **Solution Approach**: Microservices Architecture\n\n### System Design\n1. **Question**: Design Amazon Prime Video\n   **Components**:\n   - Content Delivery Network\n   - Recommendation System\n   - Streaming Architecture\n\n## Interview Process\n1. Online Assessment\n2. Phone Screen\n3. Virtual Onsite\n\n## Preparation Tips\n- Study Leadership Principles\n- Practice System Design\n- Review Distributed Systems'
FROM companies WHERE name = 'Amazon';

-- Meta Resources
INSERT INTO interview_resources (company_id, title, description, video_url, guide_content)
SELECT 
  id,
  'Meta Technical Interview Guide',
  'Facebook/Meta interview preparation',
  'https://www.youtube.com/embed/PIeiiceWe_w',
  E'# Meta Interview Guide\n\n## Coding Interview Questions\n\n### Algorithms\n1. **Question**: Design Facebook''s News Feed\n   **Solution**: Use heap for top posts, caching for performance\n\n2. **Question**: Implement a friend recommendation system\n   **Approach**: Graph algorithms, BFS/DFS\n\n### System Design\n1. **Question**: Design Facebook Messenger\n   **Components**:\n   - Real-time messaging\n   - Presence system\n   - Message storage\n   - Push notifications\n\n### Behavioral\n1. **Question**: Tell me about a technically challenging project\n   **Framework**: Problem, Approach, Solution, Impact\n\n## Interview Process\n1. Initial Screen\n2. Technical Phone Screen\n3. Onsite Interviews\n\n## Key Areas\n- Graph Algorithms\n- Distributed Systems\n- Product Design'
FROM companies WHERE name = 'Meta';

-- Apple Resources
INSERT INTO interview_resources (company_id, title, description, video_url, guide_content)
SELECT 
  id,
  'Apple Interview Preparation',
  'Complete guide for Apple interviews',
  'https://www.youtube.com/embed/5ywX6y3yJdw',
  E'# Apple Interview Guide\n\n## Technical Questions\n\n### iOS Development\n1. **Question**: Explain the iOS app lifecycle\n   **Key Points**: States, Transitions, Memory Management\n\n2. **Question**: Implement a custom UIView animation\n   **Solution**: Core Animation, UIKit Dynamics\n\n### System Design\n1. **Question**: Design iCloud\n   **Components**:\n   - Storage System\n   - Sync Engine\n   - Security Architecture\n\n### General Programming\n1. **Question**: Implement a thread-safe singleton\n   **Answer**: Use dispatch_once or atomic properties\n\n## Interview Process\n1. Phone Screen\n2. Technical Rounds\n3. Team Fit\n\n## Focus Areas\n- UI/UX Design\n- Performance Optimization\n- Security Best Practices'
FROM companies WHERE name = 'Apple';