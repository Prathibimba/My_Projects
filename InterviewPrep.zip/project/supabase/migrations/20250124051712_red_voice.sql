/*
  # Interview Preparation Platform Schema

  1. New Tables
    - `companies`
      - `id` (uuid, primary key)
      - `name` (text)
      - `logo_url` (text)
      - `description` (text)
      - `created_at` (timestamp)
    
    - `interview_resources`
      - `id` (uuid, primary key)
      - `company_id` (uuid, foreign key)
      - `title` (text)
      - `description` (text)
      - `video_url` (text)
      - `guide_content` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read data
*/

CREATE TABLE companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  logo_url text,
  description text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE interview_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES companies(id),
  title text NOT NULL,
  description text,
  video_url text,
  guide_content text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE interview_resources ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated users to read companies"
  ON companies
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to read interview resources"
  ON interview_resources
  FOR SELECT
  TO authenticated
  USING (true);