/*
  # Add company data and interview resources

  1. Data Insertion
    - Add sample companies with logos and descriptions
    - Add interview preparation resources with videos and guides
  
  2. Companies added:
    - Google
    - Microsoft
    - Amazon
    - Meta
    - Apple
*/

-- Insert companies
INSERT INTO companies (name, logo_url, description) VALUES
  ('Google', 'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?auto=format&fit=crop&q=80&w=200', 'Leading technology company known for search, cloud computing, and innovative solutions'),
  ('Microsoft', 'https://images.unsplash.com/photo-1642132652075-2b0bfae25803?auto=format&fit=crop&q=80&w=200', 'Global technology corporation specializing in software, cloud services, and hardware'),
  ('Amazon', 'https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?auto=format&fit=crop&q=80&w=200', 'E-commerce and cloud computing giant with diverse technology offerings'),
  ('Meta', 'https://images.unsplash.com/photo-1633675254053-d96c7668c3b8?auto=format&fit=crop&q=80&w=200', 'Social media and technology company focused on connecting people and building the metaverse'),
  ('Apple', 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&q=80&w=200', 'Innovation leader in consumer electronics, software, and services');

-- Insert interview resources
INSERT INTO interview_resources (company_id, title, description, video_url, guide_content) 
SELECT 
  id as company_id,
  'Technical Interview Preparation' as title,
  'Comprehensive guide for technical interviews' as description,
  'https://www.youtube.com/embed/dQw4w9WgXcQ' as video_url,
  E'# Interview Preparation Guide\n\n## Coding Round\n- Data Structures & Algorithms\n- System Design\n- Problem Solving\n\n## Technical Topics\n- Programming Languages\n- Database Systems\n- Operating Systems\n- Computer Networks\n\n## Behavioral Questions\n- Leadership Examples\n- Project Experience\n- Conflict Resolution\n\n## Tips\n- Practice coding on whiteboard\n- Review company values\n- Prepare questions for interviewer' as guide_content
FROM companies;

INSERT INTO interview_resources (company_id, title, description, video_url, guide_content)
SELECT 
  id as company_id,
  'System Design Interview Guide' as title,
  'Learn how to tackle system design interviews' as description,
  'https://www.youtube.com/embed/dQw4w9WgXcQ' as video_url,
  E'# System Design Interview Guide\n\n## Key Concepts\n- Scalability\n- Load Balancing\n- Caching\n- Database Design\n\n## Common Questions\n- Design a Social Network\n- Design a URL Shortener\n- Design a Chat Application\n\n## Best Practices\n- Start with Requirements\n- Consider Scale\n- Discuss Trade-offs' as guide_content
FROM companies;