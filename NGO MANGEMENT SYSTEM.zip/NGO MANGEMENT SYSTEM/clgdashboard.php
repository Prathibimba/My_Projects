<?php
include("Connection.php");
session_start();
$clggid = $_SESSION['ClgId'];
if (!isset($_SESSION['EmailId'])) {
    header("location: clglogin.php");
}
?>
<?php error_reporting(E_ALL ^ E_NOTICE); ?>

<html>

<head>
    <title>College Profile</title>
    <link rel="stylesheet" href="css/homeCss.css">

</head>

<body>
    <style>
        #headersection {
            text-align: center;
        }

        #backbtn {
            padding: 5px;
            font-size: 15px;
            text-transform: uppercase;
            background-color: aqua;
            color: black;
            border-radius: 5px;
            float: left;

        }

        #logoutbtn {
            padding: 5px;
            font-size: 15px;
            text-transform: uppercase;
            background-color: aqua;
            color: black;
            border-radius: 5px;
            float: right;

        }

        #profile {
            background-color: lightgray;
            position: center;
            width: 320px;
            height: 400px;
            padding: 20px;
            align-items: center;
            justify-content: center;
            text-align: left;
        }

        table,
        td,
        th {
            border: 2px solid;

        }

        table {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 50%;
            margin-top: 50px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }


        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #8e44ad;
            color: white;
        }
    </style>
    <br>
    <center>
        <h1>College Profile</h1>
    </center>
    <center>
        <table id="customers">
            <thread>
                <tr>
                    <th>fullname</th>
                    <th>qualification</th>
                    <th>email</th>
                    <th>phone</th>
                    <th>adharnum</th>
                </tr>
            </thread>
            <tbody>
                <?php
                $query1 = mysqli_query($con, "SELECT * FROM clg_registeration WHERE clg_id='$clggid'");
                $clg = mysqli_fetch_assoc($query1);
                echo '<br> ';

                echo '<h1>' . $clg['collegename'] . "'s Dashboard" . '</h1>';
                echo "<h2></br>Scribes registered for your college: </h2>";
                $query2 = mysqli_query($con, "SELECT * FROM scribe_register where collegeid='$clggid'");
                while ($r = mysqli_fetch_array($query2, MYSQLI_ASSOC)) {

                    echo '<tr>';
                    echo '<td>' . $r['fullname'] . '</td>';
                    echo '<td>' . $r['qualification'] . '</td>';
                    echo '<td>' . $r['email'] . '</td>';
                    echo '<td>' . $r['phone'] . '</td>';
                    echo '<td>' . $r['adharnumber'] . '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </center>
    <br>
    <br>
    <div id="mainsection">
        <div id="headersection">
            <a href="clglogin.php" class="btn">back</a>
            <a href="scribes.php" class="btn">logout</a>

        </div>
</body>

</html>