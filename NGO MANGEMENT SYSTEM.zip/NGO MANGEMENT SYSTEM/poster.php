<?php
require("Connection.php");

session_start();
if(!isset($SESSION['clg']))
{
    header("loaction: clglogin.php");
}




?>
<html>
    <head>
        <title>scribe details</title>
        <style>
        body
      {
        font-family: poppins;
        background-color: #ecedef;
        line-height: 1.8;
        background:url(images/blue.jpg);
      }
</style>
    </head>
    <body>

        <center>
                <?php
                $query = mysqli_query($con, "SELECT * FROM clg_registeration");
                $result= $query;
                while($r=mysqli_fetch_array($result)){ 
                ?>
                <h2><?=$r['collegename'];?></h2>
                <h3><?=$r['email'];?></h3>
                <h3><?=$r['phone'];?></h3>
                <h3><?=$r['date'];?></h3>
                <h3><?=$r['exmcenter'];?></h3>
                <a href="scribereg.php">register</a>
                <?php
                }
                ?>
        </center>
    </body>
</html>