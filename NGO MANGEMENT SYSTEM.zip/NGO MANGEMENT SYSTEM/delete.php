<?php
require('Connection.php')
?>
<?php
$delete=$_GET['delete'];
$query="DELETE FROM add_post WHERE id='$delete'";
$query_run = mysqli_query($con,$query);
if($query_run)
{

    echo '<script>
alert("deleted sucessfully");
window.location="campstableupdate.php"
</script>';
}
else{
    echo'<script>
    alert("unsucessfull");
    window.location="campstableupdate.php"
    </script>';
}
?>