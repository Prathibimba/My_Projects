<?php
require('Connection.php')
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>campaignS</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'poppins';
            background-color: #ecedef;
            line-height: 1.8;
        }

        a {
            text-decoration: none;
        }

        #container {
            max-width: 430px;
            margin: 30px auto;
            padding: 20px;
        }

        .form-wrap {
            background: #fff;
            padding: 15px 25px;
            color: #333;
            border-top: 4px solid #39c9a5;
            border-radius: 05px;
        }

        .form-wrap h1,
        .form-wrap p {
            text-align: center;

        }

        .form-wrap .form-group {
            margin-top: 15px;
            display: inline;
        }

        .form-wrap .form-group label {
            display: block;
            color: #666;
            font-size: 17px;
        }

        .form-wrap .form-group input {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }
        .form-wrap .form-group textarea {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }

        .form-wrap .form-group[type="text"],
        select {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }

        .form-wrap button {
            display: block;
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background-color: #49c1a2;
            color: #fff;
            border: 1px solid #49c1a2;
            font-family: 'poppins';
            font-size: 1s;
            transition: 1s;
        }

        .form-wrap button :hover {
            background-color: #37a08e;
            transition: 1s;
        }

        .footer {
            text-align: 13px;
            margin-top: 20px;
            color: #333;
        }

        .footer a {
            color: #49c1a2;
        }
    </style>

</head>

<body>
    <?php
    if (isset($_GET['id'])) {
        $id = mysqli_real_escape_string($con, $_GET['id']);

        $query1 = mysqli_query($con, "SELECT * from add_post WHERE id='$id'");
        $result1 = $query1;
        while ($r = mysqli_fetch_array($result1)) {
    ?>
    <div id="container">

<div class="form-wrap">

    <form action="code.php" method="POST" enctype="multipart/form-data">

        <div class="form-group">
            <label for="">ID</label>
            <input type="text" name="id" value="<?= $r['id']; ?>"></br>
        </div>

        <div class="form-group">
            <label for="">TITLE</label>
            <input type="text" name="title" value="<?= $r['title']; ?>"></br>
        </div>

        <div class="form-group">
            <label>DESCRIPTION</label>
            <textarea name="description" rows="4"><?= $r['description']; ?></textarea></br>
        </div>
        <div class="form-group">
            <label for="">CAMPS</label>
            <input type="file" name="image_new" ></br>
            <input type="hidden" name="image" value="<?= $r['image']; ?>">
        </div>
        <div>
            </br>
            <button type="submit" name="update">Update</button>
        </div>
    </form>

</div>
<div>
            
    <?php
        }
    }
    ?>
</body>

</html>
