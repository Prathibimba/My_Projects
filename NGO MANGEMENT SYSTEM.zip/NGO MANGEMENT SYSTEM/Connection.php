<?php
$con = mysqli_connect("localhost","root","","ngo");
if(mysqli_connect_error())
{
  echo" Can't Connect";
}

