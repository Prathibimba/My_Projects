<?php
require("Connection.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registeration Form</title>
    <link rel="stylesheet" href="css/donorstyle.css">

    </head>

<body>


    <div class="wrapper">
        <div class="registeration_form">
            <div class="title">
                Become a Donor!
            </div>
            <form action="registerharsh.php" method="POST">
                <div class="form_wrap">
                    <div class="input_grp">
                        <div class="input_wrap">
                            <label for="fname">First Name</label>
                            <input type="text" id="fname" name="firstname" required>
                        </div>

                        <div class="input_wrap">
                            <label for="lname">Last Name</label>
                            <input type="text" id="lname" name="lastname" required>
                        </div>
                    </div>

                    <div class="input_wrap">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="input_wrap">
                        <label for="phone">Phone</label>
                        <input type="text" id="phone" name="number" required>
                    </div>



                    <div class="input_wrap">
                        <label>Gender</label>
                        <ul type="none">
                            <li>
                                <label class="radio_wrap">
                                    <input type="radio" name="gender" value="male" class="input_radio">
                                    <span>Male</span>
                                </label>
                            </li>
                            <li>
                                <label class="radio_wrap">
                                    <input type="radio" name="gender" value="female" class="input_radio">
                                    <span>Female</span>
                                </label>
                            </li>
                        </ul>
                    </div>
                    <div class="input_wrap">
                        <label for="Bloodgrp">Blood Group</label>

                        <select name="bloodgroup1" required>
                            <option value=""> --choosebloodgroup--</option>
                            <?php
                            $resultset_AllBloodgroups = $con->query("SELECT * FROM tb_bloodgroups");
                            while ($bloodgroup = mysqli_fetch_array($resultset_AllBloodgroups, MYSQLI_ASSOC)) :;
                            ?>
                            <option value="<?php echo $bloodgroup["Bloodgroup_ID"]; ?>">
                                           <?php echo $bloodgroup["Bloodgroup_name"]; ?>
                            </option>
                        <?php
                        endwhile;
                        ?>
                        </select>
                    </div>
                    <div class="input_wrap">
                        <label for="">city</label>
                        <select name="bloodgroup_center1" required>
                            <option value="">--choose city--</option>
                            <?php
                            $resultset_AllbgCenters = $con->query("SELECT * FROM tb_bloodgroup_centers");
                            while ($bgcenter = mysqli_fetch_array($resultset_AllbgCenters, MYSQLI_ASSOC)) :;
                            ?>
                            <option value="<?php echo $bgcenter["Center_ID"]; ?>">
                                           <?php echo $bgcenter["Center_Names"]; ?>
                            </option>
                            <?php
                            endwhile;
                            ?>
                        </select>
                       
                    </div>


                    <a href="Home.php"><input type="submit" value="Register Now" class="submit_btn"></a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>