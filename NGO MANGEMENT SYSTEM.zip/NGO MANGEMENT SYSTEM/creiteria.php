<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criteria</title>
    <style>
       body{
        background-image: url(images/Bloodimg.jpg);
        background-size:cover;
        font-family: sans-serif;
        margin-top: 40px;
       }

       .wraprules{
          min-height: 100vh;
          width: fit-contents;
          display:flex;
          justify-content: center;
          align-items: center;
    }
      
      .rules{
       background:white;
       padding: 25px;
       border-radius: 5px;
       width:700px;
       align-items: center;
       }
    
       .rules.title2{
        text-align:left;
        font-size: 40px;
        text-transform: uppercase;
        color: #ebd0ca;
        letter-spacing: 500;
       } 
       
       .rules.ul{
        align-items: left;
       }
       .rules .submit_btn{
       display: inline-block;
       font-size: 15px;
       padding: 8px;
       border-radius: 3px;
       color: white;
       cursor: pointer;
       background: black;
      }
    </style>
</head>
<body>
    <div class="wraprules">
     <div class="rules">
        <div class="title2"> <h3>CRITERIA TO DONATE BLOOD.</h3></div>
    
    <ul><h3>Please read the below conditions carefully before regesitering as donor.</h3></ul>
    <li>The donor must be fit and healthy, and should not be suffering from transmittable diseases.</li>
    <li>Age and weight- Between 18–65 years old and should weigh a minimum of 50  kg.</li>
    <li>Pulse rate- Between 50 and 100 without irregularities.</li>
    <li>Hemoglobin level- A minimum of 12.5 g/dL.</li>
    <li>Blood pressure- Diastolic: 50–100 mm Hg, Systolic: 100–180 mm Hg.</li>
    <li>Body temperature- Should be normal, with an oral temperature not exceeding 37.5 °C.</li>
    <li>The time period between successive blood donations should be more than 3 months.</li>
    </ul>
    
    <ul><h3>Individuals under certain conditions are deemed ineligible to donate blood.</h3></ul>
    <li>Have been tested HIV positive.</li>
    <li>Have asthma with active symptoms, and severe asthma patients.</li>
    <li>Had fits, tuberculosis or allergic disorders in the past.</li>
    <li>Pregnant or breastfeeding women.</li>
    <li>Consumed alcohol in the past 24 hours.</li>
    <li>Underwent immunization in the past 1 month.</li>
    <li>Underwent major dental procedures or general surgeries in the past 1 month.</li>
    <li>Treated for rabies or received Hepatitis B vaccine in the past 6 months.</li>
    <li>Women who have had miscarriage in the past 6 months</li>
    
    </ul>
    <br>
   
    <input type="checkbox" required>
    <label>I agree</label>
    <br>
    </br>
    <a href="becomedonor.php"><input type="submit" value="All set to register" class="submit_btn"></a>
    </div>
    </div>
</body>
</html>