<?php
require("Connection.php")
?>
<?php
$delete=$_GET['delete'];
$query="DELETE FROM clg_registeration WHERE clg_id='$delete'";
$query_run = mysqli_query($con,$query);
if($query_run)
{

    echo '<script>
alert("deleted sucessfully");
window.location="clgremove.php"
</script>';
}
else{
    echo'<script>
    alert("unsucessfull");
    window.location="clgremove.php"
    </script>';
}
?>