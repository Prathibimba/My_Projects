<html>
    <head>
        <title>home</title>
        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"/>
        <!--<link rel="stylesheet" href="donorstyle.css">-->
        <link rel="stylesheet" href="css/homeCss.css">
        <link rel="stylesheet" href="css/blood.css">

            </head>
    <body>
        <section class="header">

            <a href="home.php" class="logo">Care INDIA.</a>
         
            <nav class="navbar">
               <a href="home.php">home</a>
               <a href="project.php">Projects</a>
               <a href="campaigns.php">campaigns</a>
               <a href="aboutus.php">About us</a>
               <a href="contactus.php">Cantact us</a>
         
         </nav>
         </section>
<br>
<br>
    <!--menu side bar strats-->
    <section>
        <div class="nevigation" style="background:url(images/Bloodimg.jpg)no-repeat"  >
            
        <ul>
                <li class="side-menu">
                    <a href="searchdonor.php">Search Donor</a>
                </li>

                <li class="side-menu">
                    <a href="becomedonor.php">Become a Donor</a>
                </li>
            </ul>
        </div>
    </section>
    <!--menu side bar ends-->

     
 <!--custom js file link -->
      <script> src="script.js"</script>
      <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>

    </body>
</html>