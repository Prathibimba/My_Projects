<?php
require('Connection.php')
?>
<?php
if(isset($_POST['update']))
{
    $id = $_POST['id'];
    $title =$_POST['title'];
    $description =$_POST['description'];
    $old_image=$_POST['image'];
    $new_image=$_FILES['image_new']['name'];
    $folder= 'images';
    move_uploaded_file ($filetmpname,$folder.$new_image);
    $query = "UPDATE add_post SET title='$title',description='$description',image='$new_image' WHERE id='$id' ";
    $query_run = mysqli_query($con,$query);
    if($query_run)
    {

        echo '<script>
    alert("updated sucessfully");
    window.location="updatecamps.php"
    </script>';
    }
    else{
        echo'<script>
        alert("unsucessfull");
        window.location="updatecamps.php"
        </script>';
    }
    
}
if(isset($_POST['add_post']))
{
    $title = $_POST['title'];
    $description = $_POST['description'];
    $filename =$_FILES['image']['name'];
    $filetmpname=$_FILES['image']['tmp_name'];
    $folder= 'images';
    move_uploaded_file ($filetmpname,$folder.$filename);
    $query = "INSERT INTO add_post(title,description,image) VALUES('$title','$description','$filename')";
    $query_run = mysqli_query($con,$query);
    if($query_run)
    {
        
    echo '<script>
    alert("post created sucessfully");
    window.location="campaigns.php"
    </script>';
   }
   else{
    echo'<script>
    alert("post  not created");
    window.location="addpost.php"
    </script>';
   }
}

?>
