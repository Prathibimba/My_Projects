<?php
require("Connection.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
  <link rel="stylesheet" href="css/admincss.css">
  <title>Document</title>
  <style>
    body{
      background-color: white;
    }
    </style>
</head>


<body>
  <div class="login-form">
    <h2>ADMIN LOGIN PANEL</h2>

    <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">

      <div class="input-field">
        <i class="fa-solid fa-circle-user"></i>
        <input type="text" placeholder="Admin Name" name="adminname">
      </div>

      <div class="input-field">
        <i class="fa-solid fa-lock"></i>

        <input type="password" placeholder="Password" name="adminpassword">
      </div>

      <button type="submit" name="Login">Login </button>

      <div class="extra">
        <a href="#">Forgot Password?</a>
      </div>
    </form>
  </div>
  <?php
  if (isset($_POST['Login'])) {
    $query = "SELECT * FROM admin_login WHERE  admin_name = '$_POST[adminname]' AND admin_password = '$_POST[adminpassword]'";
    $result = mysqli_query($con, $query);
    if (mysqli_num_rows($result) == 1) {
      session_start();
      $_SESSION['AdminLoginId'] = $_POST['adminname'];
      header("location: adminpanel.php");
    } else {
      echo '<script>alert("Incorrect Password") </script>';
    }
  }

  ?>
</body>

</html>