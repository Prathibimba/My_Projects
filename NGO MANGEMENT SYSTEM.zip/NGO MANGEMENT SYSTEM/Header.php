<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/homeCss.css">
    <title>Header</title>
</head>

<body>

    <!-- header section starts  -->

    <section class="header">

        <a href="home.php" class="logo">Care INDIA.</a>

        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="project.php">Projects</a>
            <a href="campaigns.php">campaigns</a>
            <a href="aboutus.php">About us</a>
        </nav>

    </section>
    
    <!--header section ends-->

</body>

</html>