<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>

 <!-- swiper css link  -->
 <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

<!-- font awesome cdn link  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<!-- custom css file link  -->
<link rel="stylesheet" href="css/homeCss.css">
<style>

  .heading{
    animation:fadeIn .2s linear backwards .6s;
  }
   .intro h1{
    font-size: x-large;
   }
   .intro p{
   font-size: 15px;
   animation:fadeIn .2s linear backwards .6s;
}
.bloodmenu .box-container{
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr));
  gap: 1.5rem;
}
.bloodmenu .box-container .box{
  padding: 3rem 1rem;
  text-align: center;
  background-color: lavender;

}
.bloodmenu .box-container .box{
   background-color:plum;
}  
.bloodmenu .box-container .box:hover{
  background: var(--light-black);
}

.bloodmenu .box-container .box img{
  height: 10rem;
}

.bloodmenu .box-container .box h3{
  color: black;
  font-size: 2rem;
  padding-top: 1rem;
}
.heading-title{
  animation:fadeIn .2s linear backwards .6s;
}
</style>
</head>
<body>
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo">Care INDIA.</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="project.php">Projects</a>
      <a href="campaigns.php">campaigns</a>
      <a href="aboutus.php">About us</a>
     

   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<!--banner image starts-->
<section class="bloodbody">
<div class="heading" style="background:url(images/Frontscribe.jpg)no-repeat">
   
</div>
<br>
<br>
<!--banner image ends-->
<div class="intro">
<center><h1>Drishti Programme By CARE India.</h1>
<p>CARE. India is dedicated to information on blood transfusion 
    and resources. It is the policy formulating apex body 
    in relation to all matters paertaining to operation of
     blood centers. We monitor the blood banks centers all
      over the state and also ensure invlovmenet of other
       ministries and other health programmes for varius 
       activities relate to Blood Transfusion Services(BTS)</p>
</div>
<br>
<div class="bloodmenu">
<h1 class="heading-title"> Our Services </h1>
<div class="box-container">

    <div class="box">
    <a href="scribes.php"><img src="images/scriberegicon.png" alt=""></a>
    <h3>Become a scribe</h3>
    </div>
    <div class="box">

        < <a href="clgreg.php"><img src="images/clgreg.png" alt=""></a>
                     <h3>Register here to request scribes</h3>
                 </div>

                 <div class="box">
                     <a href="clglogin.php"><img src="images/dashboard (1).png" alt=""></a>
                     <h3>View Alloted Scribes</h3>
                 </div>
</div>
</div>
<div class="gallery"></div>

</section>

<!--footer section starts-->
<section class="footer">
    <div class="box-container">
        <div class="box">
            <h1>quick links</h1>
      <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
      <a href="project.php"><i class="fas fa-angle-right"></i>Projects</a>
      <a href="campaigns.php"><i class="fas fa-angle-right"></i>campaigns</a>
      <a href="aboutus.php"><i class="fas fa-angle-right"></i>About us</a>
        </div>

        <div class="box">
            <h1>Extra links</h1>
      <a href="#"><i class="fas fa-angle-right"></i>Ask Quations</a>
      <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
      <a href="#"><i class="fas fa-angle-right"></i>Privecy Policy</a>
      <a href="#"><i class="fas fa-angle-right"></i>Terms of Uses</a>
        </div>

        <div class="box">
            <h1>Contact Info </h1>
      <a href="#"><i class="fas fa-phone"></i>9902709858</a>
      <a href="#"><i class="fas fa-phone"></i>9481161283</a>
      <a href="#"><i class="fas fa-envelope"></i>lavanya@1214gmail.com</a>
      <a href="#"><i class="fas fa-map"></i>Mumbai, India-215485</a>
        </div>
    </div>
</section>


<!--footer section ends-->



<!--swiper js link-->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>


<!--custom js link-->
<script src="script.js"></script>
</body>
</html>