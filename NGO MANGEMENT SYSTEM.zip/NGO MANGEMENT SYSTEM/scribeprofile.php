<?php
include("adminconnection.php");
session_start();
$user_id = $_SESSION['scribe'];
if(!isset($_SESSION['scribe'])){
  header("location:scribelogin.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <!-- custom css file link  -->
<link rel="stylesheet" href="../css/homeCss.css">
<style>
        body{
            background-color: white;
           }
        *:focus{
            outline:none;
        }   
        .profile{
            box-sizing: border-box;
            width: 360px;
            height: 600px;
            border: 2px solid black;
            box-shadow: -3px -3px 7px #ffffff73,
                        3px 3px 5px rgba(90,90,90);
            background-color:#dfacae;
            margin-top: 50px;
            overflow: hidden;
        }
        img{
            box-sizing: border-box;
            
            width: 149px;
            height: 149px;
            border-radius: 50%;
            margin: 0;
            border: 5px black;
            padding: 3px;
            background-color: aliceblue;
        }
        b{
            display: block;
            box-sizing: border-box;
            background: none;
            color: black;
            margin-bottom: 30px;
            padding: 4px;
            width: 220px;
            height: 32px;
            border: none;
            border-bottom: 1px solid black;
            font-family: 'Roboto',sans-serif;
            font-size: 400;
            font-size: 15px;
            transition: 0.2s ease;
        }
        b{
            border-bottom: 2px solid black;
            color: black;
            transition: 0.3 ease;
        }
        button{
            display: block;
            padding: 10px;
            border:1px solid #49c1a2;
            background-color: #49c1a2;
            color: #ffffff73;
            height: 30px;
            width: 100%;
            font-family: 'poppins';
            margin-top: 20px;
            transition: 1s;
        }
button:hover{
    background-color: #37a08e;
transform: 1s;
}

        
    </style>



</style>
</head>
<body>

<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo">Care INDIA.</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="project.php">Projects</a>
      <a href="campaigns.php">campaigns</a>
      <a href="aboutus.php">About us</a>
     

   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->
<center>
<h1>Welcome to your profile!</h1>

 
<div id="profile">
  <?php
  $select = mysqli_query($con,"SELECT * FROM scribe_register WHERE id='$user_id'");
  if(mysqli_num_rows($select)>0)
  {
$scribe = mysqli_fetch_assoc($select);
  }
  ?>
  <img scr="" ><br><br>
  <b>fullname :</b><?php echo $scribe['fullname']?> <br><br>
  <b>email :</b><?php echo $scribe['email']?> <br><br> 
  <b>phone :</b><?php echo $scribe['phone']?> <br><br>
  <b>adharnum :</b><?php echo $scribe['adharnumber']?> <br><br>

</div>
</center>
<section class="headersection">
<div>
  <div class= back>
  <button class="btn">Back</button>
</div>
<div class="logout">
  <button class="btn">Log out</button>
  </div>
</div>
</section>


<!--footer section starts-->
<section class="footer">
    <div class="box-container">
        <div class="box">
            <h1>quick links</h1>
      <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
      <a href="project.php"><i class="fas fa-angle-right"></i>Projects</a>
      <a href="campaigns.php"><i class="fas fa-angle-right"></i>campaigns</a>
      <a href="aboutus.php"><i class="fas fa-angle-right"></i>About us</a>
        </div>

        <div class="box">
            <h1>Extra links</h1>
      <a href="#"><i class="fas fa-angle-right"></i>Ask Quations</a>
      <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
      <a href="#"><i class="fas fa-angle-right"></i>Privecy Policy</a>
      <a href="#"><i class="fas fa-angle-right"></i>Terms of Uses</a>
        </div>

        <div class="box">
            <h1>Contact Info </h1>
      <a href="#"><i class="fas fa-phone"></i>9902709858</a>
      <a href="#"><i class="fas fa-phone"></i>9481161283</a>
      <a href="#"><i class="fas fa-envelope"></i>lavanya@1214gmail.com</a>
      <a href="#"><i class="fas fa-map"></i>Mumbai, India-215485</a>
        </div>
    </div>
</section>

<!--footer section ends-->



<!--swiper js link-->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>


<!--custom js link-->
<script src="script.js"></script>
</body>

</html>