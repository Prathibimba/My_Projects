<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Projects</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/homeCss.css">

</head>

<body>

   <!-- header section starts  -->

   <section class="header">

      <a href="home.php" class="logo">Care INDIA.</a>

      <nav class="navbar">
         <a href="home.php">home</a>
         <a href="project.php">Projects</a>
         <a href="campaigns.php">campaigns</a>
         <a href="aboutus.php">About us</a>
         < <a href="contactus.php">Cantact us</a>

      </nav>

      <div id="menu-btn" class="fas fa-bars"></div>

   </section>

   <!-- header section ends -->

   <div class="heading" style="background:url(images/campaign.3.jpg ) no-repeat">
      <!-- <h1>Projects</h1> -->
   </div>

   <!-- packages section starts  -->

   <section class="home-project">

      <h1 class="heading-title">OUR PROJECTS</h1>

      <div class="box-container">

         <div class="box">
            <div class="image">
               <img src="images/blood-donation.jpg" alt="">
            </div>
            <div class="content">
               <h3>Blood Donation</h3>
               <p>For The One In Need</p>
               <a href="BloodMainpg.php" class="btn">Explore</a>
            </div>
         </div>

         <div class="box">
            <div class="image">
               <img src="images/mainscribs.jpg" alt="">
            </div>
            <div class="content">
               <h3>Scribes</h3>
               <p>Spread the love you got</p>
               <a href="ScribeFrontPg.php" class="btn">Explore</a>
            </div>
         </div>
         
         

</body>

</html>

