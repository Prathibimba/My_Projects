<?php
require("Connection.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>home</title>
    <style>
       
        *,

        *::before
        *::after{
            box-sizing: border-box;
            margin:0;
            padding: 0;

        }

        body{
            font-family: sans-serif;
            height: 60vh;
            display: grid;
            justify-content: center;
            align-items: center;
            color:black;
            font-size: 0.9rem;
            background-color: white;
        }
        .table-container{
            padding: 0 10%;
            margin: 40px auto 0;
        }

        .heading{
          font-size: 40px;
          text-align: center;
          color:#3c3f44;
          margin-bottom: 40px;
        }

        
        .table{
            width: 100%;
            border-collapse: collapse;
        }

        .table thead tr th{
            font-size: 14px;
            font-weight: medium;
            letter-spacing: 0.35px;
            color:white;
            opacity: 1;
            padding: 12px;
            vertical-align: top;
            border: 1px solid #dee2e685;
            background-color:#8e44ad;
            font-family: Arial, Helvetica, sans-serif;
        }

        .table tbody{
            font-size: 14px;
            letter-spacing: 0.35px;
            font-weight: normal;
            color: black;
            background-color:lightgray;
            padding: 8px;
            text-align: center;
            border: 1px solid #dee2e685;
        }

        .table .text_open{
            font-size: 14px;
            font-weight: bold;
            letter-spacing: 0.35px;
            color: #FF1046;

        }

        .table tbody tr td .btn{
            width:130px;
            text-decoration: none;
            line-height: 35px;
            display: inline-block;
            font-weight: medium;
            background-color: lightgray;
            color:black;
            text-align: center;
            vertical-align: middle;
            user-select:none;
            border: 1px solid transparent;
            font-size: 14px;
            opacity: 1;
        }

        @media(max-width: 768px){
            .table thead{
         display: none;
            }
            .table .table tbody, .table tr, .table td{
                display: block;
                width: 100%;

            }
            .table tr{
                margin-bottom: 15px;

            }
            .table tbody tr td{
                text-align: right;
                padding-left: 50%;
                position: relative;

            }
            .table td:before{
                content: attr(data-label);
                position: absolute;
                left: 0;
                width: 50%;
                padding-left: 15px;
                font-weight: 600;
                font-size: 14px;
                text-align: left;
            }
        }

    </style>


</head>
<body>
<div class="table-container">

    <h1 class="heading">DELETE POSTERS</h1>      


    <table class="table">
    <thead>
<tr>
<th>ID</th>
<th>College name</th>
<th>Email ID</th>
<th>Exam Center</th>
<th>Date</th>
<th>Remove</th>

</tr>
</thead>
<tbody>
<?php
            
                $query1 = mysqli_query($con,"SELECT * from clg_registeration");
                $result1 = $query1;
                while($r = mysqli_fetch_array($result1) ){
                ?>
                <tr>
                    <td date-label="data"><?=$r['clg_id'];?></td>
                    <td date-label="data"><?=$r['collegename'];?></td>
                    <td date-label="data"><?=$r['email'];?></td>
                    <td date-label="data"><?=$r['exmcenter'];?></td>
                    <td date-label="data"><?=$r['date'];?></td>
                    
                <td>    
                    <a href="clgdelete.php?delete=<?=$r['clg_id'];?>" class="btn">DELETE</a>
                </td>
                </tr>    
               <?php   
                }
               ?>
               </tbody>
               </table>
               </div>
 
 
 
 

        </body>
                </html>