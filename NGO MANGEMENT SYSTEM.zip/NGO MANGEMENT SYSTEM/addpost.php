<?php
require('Connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>campaignS</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'poppins';
            background-color: #ecedef;
            line-height: 1.8;
        }

        a {
            text-decoration: none;
        }

        #container {
            max-width: 430px;
            margin: 30px auto;
            padding: 20px;
        }

        .form-wrap {
            background: #fff;
            padding: 15px 25px;
            color: #333;
            border-top: 4px solid #39c9a5;
            border-radius: 05px;
        }

        .form-wrap h1,
        .form-wrap p {
            text-align: center;

        }

        .form-wrap .form-group {
            margin-top: 15px;
            display: inline;
        }

        .form-wrap .form-group label {
            display: block;
            color: #666;
            font-size: 17px;
        }

        .form-wrap .form-group input {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }
        .form-wrap .form-group textarea {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }

        .form-wrap .form-group[type="text"],
        select {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }

        


        .form-wrap button {
            display: block;
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background-color: #49c1a2;
            color: #fff;
            border: 1px solid #49c1a2;
            font-family: 'poppins';
            font-size: 1s;
            transition: 1s;
        }

        .form-wrap button :hover {
            background-color: #37a08e;
            transition: 1s;
        }

        
    </style>

</head>

<body>
<div id="container">
   
    <div class="form-wrap">
        
        <form action="code.php" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="">TITLE</label>
                <input type="text" name="title" required>
            </div>

            <div class="form-group">
                <label>DESCRIPTION</label>
                <textarea name="description" rows="4"></textarea></br>
            </div>
            <div class="form-group">
                <label for="">CAMPS</label>
                <input type="file" accept="All Files(*.*)" name="image" required></br>
            </div>
            <div>
</br>
                <button type="submit" name="add_post">Add Post</button>
            </div>
        </form>

    </div>
    <div>

    
</body>

</html>


