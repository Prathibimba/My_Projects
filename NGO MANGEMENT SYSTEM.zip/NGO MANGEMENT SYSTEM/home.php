<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>

    <!-- swiper css link  -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/homeCss.css">

</head>

<body>
    <!-- header section starts  -->

    <section class="header">

        <a href="home.php" class="logo">Care INDIA.</a>

        <div class="navbar">
            <a href="Home.php">Home</a>
            <a href="project.php">Projects</a>
            <a href="campaigns.php">campaigns</a>
            <a href="AboutUss.php">About us</a>
            <a href="adminlogin.php"> <i class="fa-solid fa-circle-user"></i> ADMIN LOGIN</a>


        </div>

    </section>
    <!--header section ends-->

    <!--home section starts-->
    <section class="home">
        <div class="fadeIn">
            <div class=" home-slider">
                <div class="w">
                    <div class="slide" style="background:url(images/mainhome1.jpg)no-repeat">
                        <div class="content">
                            <span>Care India</span>
                            <h3>Have The Courage To Give</h3>
                            <a href="project.php" class="btn">Know More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--home section ends-->

    <!--home about section starts-->
    <section class="home-about">
        <div class="image">
            <img src="images/aboutus.jpg " alt="">
        </div>
        <div class="content">
            <h3>about us</h3>

            <p>The CARE INDIA Foundation is an NGO in Karnataka headquartered in Bengaluru. Our organisation strives to help the society in two of the most crucial areas such as Health and Education.
                Since 2000, CARE INDIA has been conducting BLOOD DONATION CAMPS in most of the districts of KARNATAKA thus concerting all its efforts towards providing blood to the needy people, also CARE INDIA is a reknown NGO for providing SCRIBES for VISUALLY IMPAIRED STUDENTS all over the state. We are continuously leveraging technology to multiply our reach. </p>
            <br>
            <a href="aboutus.php" class="btn">Read More</a>
        </div>
    </section>
    <!--home about section ends-->

    <!--home project section starts-->
    <section class="home-project">
        <h1 class="heading-title">Our Projects</h1>
        <div class="box-container">

            <div class="box">
                <div class="image">
                    <img src="images/bloodmain.png" alt="">
                </div>
                <div class="content">
                    <h3>Blood Donation</h3>
                    <p>For The One In Need</p>
                    <a href="BloodMainpg.php" class="btn">Explore </a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/mainscribs.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Scribes</h3>
                    <p>Spread The Love You Got </p>
                    <a href="ScribeFrontPg.php" class="btn">Explore </a>
                </div>
            </div>

        </div>

        <!-- <div class="load-more"> <a href="#" class="btn">Load More</a></div> -->
    </section>
    <!--home project section ends-->

    <!--home campaigns section starts-->
    <section class="campiagn">
        <h1 class="heading-title">contributions</h1>
        <div class="box-container">
            <div class="box">
                <div class="image">
                    <img src="images/blood1.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Blood Donation Camp at IIM, Bengaluru</h3>
                    <p>Students donated blood on the occcasion WORLD BLOOD DONATION day, remains as a remarkable contribution for the NGO from today's youth.</p>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/scribe1.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Scribe helped Vani to write her EXAM</h3>
                    <p>Vani got passed with top 3 rank in her PDO Exam which is a biggest milestone in her life. Scribe felt an heart-felt gratification in helping her.</p>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/scribe2.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Smita's smile and confidence for having our scribe beside her!</h3>
                    <p>Scribe wrote her exam with so much pleasure in her heart which made Smita got posted for FDA at a government college, Belgavi</p>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/blood2 .jpg" alt="">
                </div>
                <div class="content">
                    <h3>Blood Donation Camp at Davangere on the occasion of 75th Independence Day.</h3>
                    <p>Bapuji education trust Employees arranged a blood donation camp which made us collect more than 300 samples in a day.</p>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/scribe3.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Koushik's Heart felt moment after writing his exam.</h3>
                    <p>Vani got passed with top 3 rank in her PDO Exam which is a biggest milestone in her life. Scribe felt an heart-felt gratification in helping her.</p>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/blood3.jpg" alt="" height="25px;">
                </div>
                <div class="content">
                    <h3>Blood Donation Camp at Chitradurga</h3>
                    <p>Students donated blood on the occcasion WORLD BLOOD DONATION day, remains as a remarkable contribution for the NGO from today's youth.</p>
                </div>
            </div>
        </div>
        <a href="campaigns.php" class="btn">Load more</a>

    </section>
    <!--home campaigns section ends-->



    <!--
    <section class="money-donate">
        <div class="content">
            <h3>Donor Recipient</h3>
            <p>Hand In Hand</p>
            <a href="donate.php" class="btn">Donate Now</a>
        </div>
    </section>
   home money donation ends-->


    <!--footer section starts-->
    <section class="footer">
        <div class="box-container">
            <div class="box">
                <h1>quick links</h1>
                <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
                <a href="project.php"><i class="fas fa-angle-right"></i>Projects</a>
                <a href="campaigns.php"><i class="fas fa-angle-right"></i>campaigns</a>
                <a href="aboutus.php"><i class="fas fa-angle-right"></i>About us</a>
            </div>

            <div class="box">
                <h1>Extra links</h1>
                <a href="#"><i class="fas fa-angle-right"></i>Ask Quations</a>
                <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                <a href="#"><i class="fas fa-angle-right"></i>Privecy Policy</a>
                <a href="#"><i class="fas fa-angle-right"></i>Terms of Uses</a>
            </div>

            <div class="box">
                <h1>Contact Info </h1>
                <a href="#"><i class="fas fa-phone"></i>9902709858</a>
                <a href="#"><i class="fas fa-phone"></i>9481161283</a>
                <a href="#"><i class="fas fa-envelope"></i>lavanya@1214gmail.com</a>
                <a href="#"><i class="fas fa-map"></i>Davangere,India-215485</a>
            </div>
        </div>
    </section>

    <!--footer section ends-->



    <!--swiper js link-->
    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>


    <!--custom js link-->
    <script src="script.jss"></script>

</body>

</html>