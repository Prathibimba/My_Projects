<?php


require("Connection.php");

        $firstname= $_POST["firstname"];
        $lastname= $_POST["lastname"];
        $email= $_POST["email"];
        $number = $_POST["number"];
        $gender = $_POST["gender"];
        $bloodgrp = mysqli_real_escape_string($con, $_POST['bloodgroup1']);
        $city = mysqli_real_escape_string($con, $_POST['bloodgroup_center1']);
        $insert = mysqli_query($con, "INSERT INTO registeration (firstname,lastname,email,number,gender,Bloodgroup_ID,center_ID) 
        VALUES('$firstname','$lastname',' $email','$number',' $gender','$bloodgrp','$city')");
        if($insert){
            echo'
            <script>
              alert("Registeration successfull!");
              window.location = "home.php";
            </script>
            ';
        }
        else{
            echo '
            <script>
            alert("Something wet wrong, try again");
            window.location = "donateblood.php";
            </script>
           ';
        }

?>