<?php
require('Connection.php')
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <title>home</title>
    <style>
        table,
        td,
        th {
            border: 1px solid;

        }

        table {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 50%;
            margin-top: 50px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #camp tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #camp tr:hover {
            background-color: #ddd;
        }

        #camp th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #8e44ad;
            color: white;
        }
    </style>


</head>

<body>


    <center>
        <h1>updated camp details</h1>
        <table id="camp">
            <thread>
                <tr>
                    <th>id</th>
                    <th>title</th>
                    <th>description</th>
                    <th>images</th>
                    <th>update</th>
                    <th>delete</th>

                </tr>
            </thread>
            <tbody>
                <?php

                $query1 = mysqli_query($con, "SELECT * from add_post");
                $result1 = $query1;
                while ($r = mysqli_fetch_array($result1)) {
                ?>
                    <tr>
                        <td><?= $r['id']; ?></td>
                        <td><?= $r['title']; ?></td>
                        <td><?= $r['description']; ?></td>
                        <td><?= $r['image']; ?></td>
                        <td>
                            <a href="updatecamps.php?id=<?= $r['id']; ?>" class="btn">Edit</a>
                        </td>
                        <td>
                            <a href="delete.php?delete=<?= $r['id']; ?>" class="btn">delete</a>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </center>
</body>

</html>