<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>

    <!-- swiper css link  -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/homeCss.css">
    <style>
        .content p{
            font-size: 12px;
        }
        .bloodmenu .box-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr));
            gap: 1.5rem;
        }

        .bloodmenu .box-container .box {
            padding: 3rem 1rem;
            text-align: center;
            align-items: flex-start;
            background-color:#844e9b;

        }

        .bloodmenu .box-container .box:hover {
            background: white;
        }

        .bloodmenu .box-container .box img {
            height: 10rem;
        }

        .bloodmenu .box-container .box h3 {
            color: black;
            font-size: 2rem;
            padding-top: none;

        }
        .bloodmenu .box-container .box p{
            font-size: 10px;
            
        }
        
        
    </style>
</head>

<body>
    <!-- header section starts  -->

    <section class="header">

        <a href="home.php" class="logo">Care INDIA.</a>

        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="project.php">Projects</a>
            <a href="campaigns.php">campaigns</a>
            <a href="aboutus.php">About us</a>

        </nav>



    </section>
    <!--header section ends-->
    <section class="home-about">
        <div class="image">
            <img src="images/aboutus.jpg " alt="">
        </div>
        <div class="content">
            <h3>about us</h3>

            <p> CARE INDIA has been conducting BLOOD DONATION CAMPS in most of the districts of KARNATAKA thus concerting all its efforts towards providing blood to the needy people, also CARE INDIA is a reknown NGO for providing SCRIBES for VISUALLY IMPAIRED STUDENTS all over the state. </p>
            <br>
            <h3>Contact</h3>
            <p>Email: caraindiango15@gmail.com <br>Phone: 585-430-6166<br>Address: Siddaramappa Extension, 3rd cross, Opp alankar plaza </p>
        </div>
    

        <div class="bloodmenu">
            <h1 class="heading-title"> CARE. India's </h1>
            <div class="box-container">

                <div class="box">
                    <h3>Vision</h3>
                    <p>No children in Karnataka shall be deprived of education<br>A Step Forward To Save People lives</p>
                </div>
                <div class="box">
                    <h3>Mission</h3>
                    <p>To reach a billions of hearts and make them help the needy ones voluntarily in comming days</p>

                </div>
                
                <div class="box">
                    <h3>Achievements</h3>
                    <p>We have achieved 4500 blood supply & 600 Blood donation camps  helped around 750 visually impaired students by allocating SCRIBES to them.helped around 750 visually impaired students by allocating SCRIBES to them</p>

                </div>
                <div class="box">


                    <h3>Promises</h3>
                    <p>helping more number of students and founding blood banks at the remaining districts of the state in coming years<br>A Step Forward To Save People lives</p>

                </div>

            </div>
        </div>
        
    </section>




    <!--footer section starts-->
    <section class="footer">
        <div class="box-container">
            <div class="box">
                <h1>quick links</h1>
                <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
                <a href="project.php"><i class="fas fa-angle-right"></i>Projects</a>
                <a href="campaigns.php"><i class="fas fa-angle-right"></i>campaigns</a>
                <a href="aboutus.php"><i class="fas fa-angle-right"></i>About us</a>
            </div>

            <div class="box">
                <h1>Extra links</h1>
                <a href="#"><i class="fas fa-angle-right"></i>Ask Quations</a>
                <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                <a href="#"><i class="fas fa-angle-right"></i>Privecy Policy</a>
                <a href="#"><i class="fas fa-angle-right"></i>Terms of Uses</a>
            </div>

            <div class="box">
                <h1>Contact Info </h1>
                <a href="#"><i class="fas fa-phone"></i>9902709858</a>
                <a href="#"><i class="fas fa-phone"></i>9481161283</a>
                <a href="#"><i class="fas fa-envelope"></i>lavanya@1214gmail.com</a>
                <a href="#"><i class="fas fa-map"></i>Mumbai, India-215485</a>
            </div>
        </div>
    </section>

    <!--footer section ends-->



    <!--swiper js link-->
    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>


    <!--custom js link-->
    <script src="script.jss"></script>
</body>

</html>