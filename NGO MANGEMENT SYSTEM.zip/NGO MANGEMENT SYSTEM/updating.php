<?php
require('Connection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/admincss.css">
      <title>Blood bank UPDATION</title>
      <style>
    body{
      background-color: white;
    }
    </style>
</head>
<body>
<form method="POST">


<div class="container">
  <div class="f-group">
    <label for="">Bloodgroup </label>
    <select name="bloodgroup" required >
      <option value=""> --choose blood group--</option>
      <?php
      $resultset_AllBloodgroups = $con->query("SELECT * FROM tb_bloodgroups");
      while ($bloodgroup = mysqli_fetch_array($resultset_AllBloodgroups, MYSQLI_ASSOC)) :;
      ?>
        <option value="<?php echo $bloodgroup["Bloodgroup_ID"]; ?>">
          <?php echo $bloodgroup["Bloodgroup_name"]; ?>
        </option>
      <?php
      endwhile;
      ?>
    </select>
  </div>
  <div class ="f-group">
    <label for="">City</label>
    <select name="bloodgroup_center" id="" required>
      <option value="">--choose city--</option>
      <?php
      $resultset_AllbgCenters = $con->query("SELECT * FROM tb_bloodgroup_centers");
      while ($bgcenter = mysqli_fetch_array($resultset_AllbgCenters, MYSQLI_ASSOC)) :;
      ?>
        <option value="<?php echo $bgcenter["Center_ID"]; ?>">
          <?php echo $bgcenter["Center_Names"]; ?>
        </option>
      <?php
      endwhile;
      ?>
    </select>
  </div>

  <div class="f-group">
    <label for="">availability</label>
    <select name="IsBloodgroupavail" id="" required  >
      <option value="">--BloodgroupAvailability--</option>
      <option value="1">YES</option>
      <option value="0">NO</option>
    </select>
  </div>
  <br><br><br> <br><br><br>
  <div class="f-group">
                <button type="submit" name="update">UPDATE</button>
            </div>
</div>
</form>
<?php
if (isset($_POST['update'])) {
    $BG = mysqli_real_escape_string($con, $_POST['bloodgroup']);
    $center = mysqli_real_escape_string($con, $_POST['bloodgroup_center']);
    $IsBGAvailable = filter_var($_POST["IsBloodgroupavail"], FILTER_VALIDATE_BOOLEAN);
    $ifexists_result = $con-> query("SELECT COUNT(*) FROM tb_bgavailability WHERE Center_ID ='$center' AND Bloodgroup_ID= '$BG'");
    $row = mysqli_fetch_array($ifexists_result);
    $ifsuccessful=FALSE;
    if($row[0]>0){
        $bgAvailUpdatequery = "UPDATE tb_bgavailability SET BG_availability='$IsBGAvailable' WHERE Center_ID ='$center' AND Bloodgroup_ID= '$BG' ;";
        $ifsuccessful = mysqli_query($con, $bgAvailUpdatequery);
      }    
    else{    
        $bgAvailInsertquery ="INSERT INTO tb_bgavailability (Bloodgroup_ID, Center_ID,BG_availability) VALUES ('$BG','$center','$IsBGAvailable');";
        $ifsuccessful = mysqli_query($con, $bgAvailInsertquery);
      }  
      if($ifsuccessful==TRUE)  
          echo "<script type='text/javascript'>alert('Updated successfully!')</script>";
      else 
          echo "<script type='text/javascript'>alert('Update failed! Please try again')</script>";
    }
?> 

</body>
</html>