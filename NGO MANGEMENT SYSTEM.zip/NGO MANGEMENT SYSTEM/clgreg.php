<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>clgRegistration</title>

    <!-- swiper css link  -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/homeCss.css">
    <link rel="stylesheet" href="css/searchdonorstyle.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'poppins';
            background-color: #ecedef;
            line-height: 1.8;
        }

        a {
            text-decoration: none;
        }

        #container {
            max-width: 430px;
            margin: 30px auto;
            padding: 20px;
        }

        .form-wrap {
            background: #fff;
            padding: 15px 25px;
            color: #333;
            border-top: 4px solid #8e44ad;
            border-radius: 05px;
        }

        .form-wrap h1,
        .form-wrap p {
            text-align: center;

        }

        .form-wrap .form-group {
            margin-top: 15px;
            display: inline;
        }

        .form-wrap .form-group label {
            display: block;
            color: #666;
            font-size: 17px;
        }

        .form-wrap .form-group input {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }

        .form-wrap .form-group[type="text"],
        select {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }

        .form-wrap .form-group[type="email"],
        select {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
            text-transform: lowercase;
        }

        .form-wrap button {
            display: block;
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background-color: #8e44ad;
            color: #fff;
            border: 1px solid #8e44ad;
            font-family: 'poppins';
            font-size: 1s;
            transition: 1s;
        }

        .form-wrap button :hover {
            background-color: #37a08e;
            transition: 1s;
        }

        .footer {
            text-align: 13px;
            margin-top: 20px;
            color: #333;
        }

        .footer a {
            color: #8e44ad;
        }
    </style>
</head>

<body>
    <?php
    session_start();
    include("Connection.php");
    if (isset($_POST['submit'])) {
        $clgname = $_POST["clgname"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $cpassword = $_POST["cpassword"];
        $phone = $_POST["phone"];
        $date = $_POST["date"];
        $exmcentre = $_POST["exmcentre"];
        $numscribes = $_POST["numscribes"];
        $emailquery = "SELECT * FROM clg_registeration WHERE email='$email'";
        $query = mysqli_query($con, $emailquery);
        $emailcount = mysqli_num_rows($query);
        if ($emailcount > 0) {
    ?>
            <script>
                alert("Email already exists");
            </script>
            <?php
        } else {
            if ($password === $cpassword) {
                $insert = "INSERT into clg_registeration(collegename, email, password, cpassword, phone, date, exmcenter, numscribes) 
            VALUES('$clgname', '$email', ' $password' ,'$cpassword', '$phone', '$date', '$exmcentre', '$numscribes' )";
                $iquery = mysqli_query($con, $insert);

                if ($insert) {
            ?>
                    <script>
                        alert("registered succesfully");
                        window.location = "scribes.php";
                    </script>
                <?php
                } else {
                ?>
                    <script>
                        alert("something went wrong");
                    </script>
                <?php
                }
            } else {
                ?>
                <script>
                    alert("Password Not Matching");
                </script>
    <?php
            }
        }
    }

    ?>

    <!-- header section starts  -->

    <section class="header">

        <a href="home.php" class="logo">Care INDIA.</a>

        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="project.php">Projects</a>
            <a href="campaigns.php">Campaigns</a>
            <a href="aboutus.php">About us</a>
            <a href="contactus.php">Cantact us</a>

        </nav>

        <div id="menu-btn" class="fas fa-bars"></div>

    </section>

    <!-- header section ends -->

    <!-- container  starts -->
    <div id="container">
        <!-- formwrap  starts -->
        <div class="form-wrap">
            <h1>Sign up</h1>
            <!--form starts-->
            <form action="" method="POST">
                <div class="form-group">
                    <label for="">College Name</label>
                    <input type="name" name="clgname" id="name" required>
                </div>

                <div class="form-group">
                    <label for="">Email</label>
                    <input type="email" name="email" required>
                </div>

                <div class="form-group">
                    <label for="">Password</label>
                    <input type="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="">Confirm Password</label>
                    <input type="password" name="cpassword" required>
                </div>

                <div class="form-group">
                    <label for="">Phone:</label>
                    <input type="text" name="phone" required>
                </div>

                <div class="form-group">
                    <label for="">Enter Exam Date</label>
                    <input type="date" name="date" id="date" required>
                </div>

                <div class="form-group">
                    <label for="">Exam Center:</label>
                    <select name="exmcentre">
                        <option type="text" value="">--choose city--</option>
                        <?php
                        $resultset = $con->query("SELECT Center_Names FROM tb_bloodgroup_centers");
                        while ($rows = $resultset->fetch_assoc()) {
                            $bloodgroupname = $rows['Center_Names'];
                            echo "<option value='$bloodgroupname'>$bloodgroupname</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="">Number of Scribes Required</label>
                    <input type="text" name="numscribes" id="" required>
                </div>
                <button type="submit" name="submit">Sign Up</button>

                <div class="bottom-text">
                    <a href="clglogin.php">Already Registered? Login Here</a>
                </div>
            </form>
            <!--form closes-->

        </div>
        <!-- formwrap  ends -->
    </div>
    <!-- container  starts -->



    </div>

    </div>


    </div>


    <br>
    <br>
    <br>
    <br>
    <br>

    <!--footer section starts-->
    <section class="footer">
        <div class="box-container">
            <div class="box">
                <h1>quick links</h1>
                <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
                <a href="project.php"><i class="fas fa-angle-right"></i>Projects</a>
                <a href="campaigns.php"><i class="fas fa-angle-right"></i>campaigns</a>
                <a href="aboutus.php"><i class="fas fa-angle-right"></i>About us</a>
            </div>

            <div class="box">
                <h1>Extra links</h1>
                <a href="#"><i class="fas fa-angle-right"></i>Ask Quations</a>
                <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                <a href="#"><i class="fas fa-angle-right"></i>Privecy Policy</a>
                <a href="#"><i class="fas fa-angle-right"></i>Terms of Uses</a>
            </div>

            <div class="box">
                <h1>Contact Info </h1>
                <a href="#"><i class="fas fa-phone"></i>9902709858</a>
                <a href="#"><i class="fas fa-phone"></i>9481161283</a>
                <a href="#"><i class="fas fa-envelope"></i>lavanya@1214gmail.com</a>
                <a href="#"><i class="fas fa-map"></i>Mumbai, India-215485</a>
            </div>
        </div>
    </section>

    <!--footer section ends-->



    <!--swiper js link-->
    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>


    <!--custom js link-->
    <script src="script.js"></script>
</body>

</html>