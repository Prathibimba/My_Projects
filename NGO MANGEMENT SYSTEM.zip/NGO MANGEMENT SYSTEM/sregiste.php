<?php
include("adminconnection.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registeration Form</title>
    <!-- custom css file link  -->
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

    .main{
    min-height: 80vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
.register{
    background-color: black;
    padding: 25px;
    border-radius: 5px;
    width:400px;
}
.register .title{
    text-align:left;
    font-size: 20px;
    text-transform: uppercase;
    color: #ebd0ca;
    letter-spacing: 500;

}
.form_wrap{
    margin-top: 35px;
}

.form_wrap .input_wrap
{
    margin-bottom: 15px;
    
}

.form_wrap .input_wrap:last-child{
    margin-bottom: 0;
}

.form_wrap .input_wrap label{
    display: block;
    margin-bottom: 3px;
    color:white;
    padding:  8px 10px ;
}

.form_wrap .input_grp{
    display: flex;
    justify-content: space-between;
}
.form_wrap .input_grp2{
    display: flex;
    justify-content: space-between;
}
.form_wrap .input_grp input[type="text"]{
  width: 165px;
}

.form_wrap input[type="text"]{
    width: 100%;
    border-radius: 3px;
    border: 1px solid #9597a6;
    padding: 10px;
    outline: none;
}
.form_wrap input[type="email"]{
    width:100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
.form_wrap .input_grp3{
    display: flex;
    justify-content: space-between;
    
}
.form_wrap input[type="text"]:focus{
    border-color: #ebd0ca;
}

.form_wrap ul{

    background: #fff;
    padding: 8px 10px ;
    border-radius: 3px;
    display: flex;
    justify-content: center;
    
}

.form_wrap ul li:first-child{
    margin-right: 15px;

}

.form_wrap ul radio_wrap{
   position: relative;
   margin-bottom: 0;
}

.form_wrap ul radio_wrap .input_radio{
    position: absolute;
    top: 0;
    right: 0;
    opacity: 0;
}

.form_wrap ul .radio_wrap span{
    display: inline-block;
    font-size: 14px;
    padding: 4px 20px;
    border-radius: 3px;
    color: #545871;
}

.form_wrap ul .input_radio:checked~span{
background: #ebd0ca;
}

.form_wrap input[type="text"], select{
    width:100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;

}
.form_wrap input[type="date"], select{
    width:100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;

}

.form_wrap input[type="password"], select{
    width:100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;

}


.form_wrap a :hover
{
    text-decoration: none;
    font-size: 12px;
    line-height: 20px;
    color: darkgray;
}




.form_wrap .submit_btn
{
    border: none;
    outline: none;
    height: 40px;
    background: #fb2525;
    color: #fff;
    font-size: 18px;
    border-radius: 20px;
    padding: 5px;
    text-transform:Capitalize; 
}




        </style>
</head>
    <body>
        <div class="main">
            <div class="register">
            <div class="title">
                Scribes Registration
                <br><br>    
                <form action="scribereg.php" method="POST">
                <div class="form_wrap">
                <div class="input_wrap">
                        <label>Full Name</label>
                        <input type="text" id="name" name="fullname" required>
                       </div>
                       
                       <div class="input_wrap">
                       <label>Qualification</label>
                       <ul type="none">
                        <li>
                            <label class="radio_wrap">
                                <input type="radio" name="radio" value="puc" class="input_radio" required>
                                <span>PUC</span>
                            </label>
                        </li>
                        <li>
                            <label class="radio_wrap">
                                <input type="radio" name="radio" value="degree" class="input_radio" required>
                                <span>DEGREE</span>
                            </label>
                        </li>
                       </ul>
                     </div>
                        
                     
                     <div class="input_wrap">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                        
                     </div>

                     <div class="input_wrap">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                     </div>
                    

                     <div class="input_wrap">
                        <label for="phone">Phone</label>
                        <input type="text" id="phone" name="number" required>
                     </div>

                     <div class="input_wrap">
                        <label for="phone">Adhar Number</label>
                        <input type="text" id="number" name="adhar" required>
                     </div>
                    
                     <div class="input_wrap">
                     <label for="">city</label>
            <select name="city">
                <option value="">--choose city--</option>
                <?php
                $resultset = $con->query("SELECT Center_Names FROM tb_bloodgroup_centers");

                while ($rows = $resultset->fetch_assoc()) {
                    $bloodgroupname = $rows['Center_Names'];
                    echo "<option value='$bloodgroupname'>$bloodgroupname</option>";
                }
                ?>
            </select>
                     </div>
                    
                     <div class="input_wrap">
                        <label for="phone"></label>
                        Available Date
                        <input type="date" name="date">
                     </div>


                     <a href="sregister.php"><input type="submit" name="submit" value="Register Now" class="submit_btn"></a>
                     <br><br>
                    <label>Already Registered Please Login</label>
<br><br>
                    
                     <a href="login.php" class="submit_btn">Log In</a>
                     

                 </div>
            </form>
        </div>
    </div>
</body>
</html>