<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>searchscribe</title>

    <!-- swiper css link  -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/homeCss.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'poppins';
            background-color: #ecedef;
            line-height: 1.8;
        }

        a {
            text-decoration: none;
        }

        #container {
            max-width: 430px;
            margin: 30px auto;
            padding: 20px;
        }

        .form-wrap {
            background: #fff;
            padding: 15px 25px;
            color: #333;
            border-top: 4px solid #39c9a5;
            border-radius: 05px;
        }

        .form-wrap h1,
        .form-wrap p {
            text-align: center;

        }

        .form-wrap .form-group {
            margin-top: 15px;
            display: inline;
        }

        .form-wrap .form-group label {
            display: block;
            color: #666;
            font-size: 17px;
        }

        .form-wrap .form-group input {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }

        .form-wrap .form-group[type="text"],
        select {
            width: 100%;
            padding: 10px;
            border: #ddd 1px solid;
            border-radius: 5px;
        }

        .form-wrap button {
            display: block;
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background-color: #49c1a2;
            color: #fff;
            border: 1px solid #49c1a2;
            font-family: 'poppins';
            font-size: 1s;
            transition: 1s;
        }

        .form-wrap button :hover {
            background-color: #37a08e;
            transition: 1s;
        }

        .footer {
            text-align: 13px;
            margin-top: 20px;
            color: #333;
        }

        .footer a {
            color: #49c1a2;
        }
    </style>
</head>

<body>
    <?php

    session_start();
    include("adminconnection.php");
    if (isset($_POST['submit'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $query = mysqli_query($con, "SELECT * FROM scribe_register WHERE email='$email' AND password='$password' ");
        if (mysqli_num_rows($query) == 1) {
            $scribe = mysqli_fetch_array($query);
            $_SESSION['scribe'] = $scribe['id'];
            echo '
    <script>
        window.location="scribeprofile.php";
     </script>
     ';
        } else {
            echo '
  <script>
  alert("Incorrect Password");
  </script>
  ';
        }
    }
    ?>



    <!-- header section starts  -->

    <section class="header">

        <a href="home.php" class="logo">Care INDIA.</a>

        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="project.php">Projects</a>
            <a href="campaigns.php">Campaigns</a>
            <a href="aboutus.php">About us</a>
            <a href="contactus.php">Cantact us</a>

        </nav>

        <div id="menu-btn" class="fas fa-bars"></div>

    </section>

    <!-- header section ends -->

    <!-- container  starts -->
    <div id="container">
        <!-- formwrap  starts -->
        <div class="form-wrap">
            <h1>Login</h1>
            <!--form starts-->
            <form action="" method="POST">
                <div class="form-group">
                    <label for="">Email</label>
                    <input type="email" name="email" required>
                </div>

                <div class="form-group">
                    <label for="">Password</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" name="submit">LOGIN</button>
            </form>
            <!--form closes-->

        </div>
        <!-- formwrap  ends -->
    </div>
    <!-- container  ends -->
    </div>
    </div>
    </div>
    <br>


    <!--footer section starts-->
    <section class="footer">
        <div class="box-container">
            <div class="box">
                <h1>quick links</h1>
                <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
                <a href="project.php"><i class="fas fa-angle-right"></i>Projects</a>
                <a href="campaigns.php"><i class="fas fa-angle-right"></i>campaigns</a>
                <a href="aboutus.php"><i class="fas fa-angle-right"></i>About us</a>
            </div>

            <div class="box">
                <h1>Extra links</h1>
                <a href="#"><i class="fas fa-angle-right"></i>Ask Quations</a>
                <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                <a href="#"><i class="fas fa-angle-right"></i>Privecy Policy</a>
                <a href="#"><i class="fas fa-angle-right"></i>Terms of Uses</a>
            </div>

            <div class="box">
                <h1>Contact Info </h1>
                <a href="#"><i class="fas fa-phone"></i>9902709858</a>
                <a href="#"><i class="fas fa-phone"></i>9481161283</a>
                <a href="#"><i class="fas fa-envelope"></i>lavanya@1214gmail.com</a>
                <a href="#"><i class="fas fa-map"></i>Mumbai, India-215485</a>
            </div>
        </div>
    </section>

    <!--footer section ends-->



    <!--swiper js link-->
    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>


    <!--custom js link-->
    <script src="script.js"></script>
</body>

</html>