/*
  # Create tables for organ donation system

  1. New Tables
    - `donors`
      - `id` (uuid, primary key)
      - `name` (text)
      - `age` (integer)
      - `blood_type` (text)
      - `email` (text)
      - `phone` (text)
      - `address` (text)
      - `organs` (text[])
      - `created_at` (timestamp)
      - `user_id` (uuid, references auth.users)

    - `recipients`
      - `id` (uuid, primary key)
      - `name` (text)
      - `age` (integer)
      - `blood_type` (text)
      - `email` (text)
      - `phone` (text)
      - `address` (text)
      - `organ_needed` (text)
      - `urgency_level` (text)
      - `medical_history` (text)
      - `created_at` (timestamp)
      - `user_id` (uuid, references auth.users)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create donors table
CREATE TABLE IF NOT EXISTS donors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  age integer NOT NULL,
  blood_type text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  organs text[] NOT NULL,
  created_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id)
);

-- Enable RLS for donors
ALTER TABLE donors ENABLE ROW LEVEL SECURITY;

-- Create policy for donors
CREATE POLICY "Users can view all donors"
  ON donors
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own donor record"
  ON donors
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create recipients table
CREATE TABLE IF NOT EXISTS recipients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  age integer NOT NULL,
  blood_type text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  organ_needed text NOT NULL,
  urgency_level text NOT NULL,
  medical_history text NOT NULL,
  created_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id)
);

-- Enable RLS for recipients
ALTER TABLE recipients ENABLE ROW LEVEL SECURITY;

-- Create policy for recipients
CREATE POLICY "Users can view all recipients"
  ON recipients
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own recipient record"
  ON recipients
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);