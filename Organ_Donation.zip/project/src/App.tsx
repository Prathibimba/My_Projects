import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import DonorRegistration from './pages/DonorRegistration';
import RecipientRegistration from './pages/RecipientRegistration';
import OrganMatching from './pages/OrganMatching';
import FindMatch from './pages/FindMatch';
import Chat from './pages/Chat';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import SignIn from './pages/SignIn';
import SignUp from './pages/SignUp';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/donor-registration" element={<DonorRegistration />} />
          <Route path="/recipient-registration" element={<RecipientRegistration />} />
          <Route path="/organ-matching" element={<OrganMatching />} />
          <Route path="/find-match" element={<FindMatch />} />
          <Route path="/chat/:matchId" element={<Chat />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;