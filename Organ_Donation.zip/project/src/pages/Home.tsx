import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Users, Award, ArrowRight } from 'lucide-react';

const Home = () => {
  const stats = [
    { icon: Heart, label: 'Lives Saved', value: '50,000+' },
    { icon: Users, label: 'Registered Donors', value: '100,000+' },
    { icon: Award, label: 'Successful Matches', value: '25,000+' },
  ];

  const successStories = [
    {
      id: 1,
      name: 'Sarah Johnson',
      story: 'Received a heart transplant in 2022',
      image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 2,
      name: 'Michael Chen',
      story: 'Kidney donor who changed a life',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      story: 'Liver transplant success story',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div 
        className="relative h-[600px] bg-cover bg-center"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1631815589968-fdb09a223b1e?auto=format&fit=crop&q=80&w=2000)',
          backgroundBlendMode: 'overlay',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-teal-900/90 to-blue-900/90">
          <div className="max-w-7xl mx-auto px-4 h-full flex items-center">
            <div className="text-white">
              <h1 className="text-5xl md:text-6xl font-bold mb-6 animate-fade-in">
                Give the Gift of Life
              </h1>
              <p className="text-xl md:text-2xl mb-8 max-w-2xl">
                Your decision to become an organ donor can save up to 8 lives and
                enhance the lives of up to 75 people.
              </p>
              <div className="space-x-4">
                <Link
                  to="/donor-registration"
                  className="inline-flex items-center px-6 py-3 bg-teal-500 hover:bg-teal-600 text-white font-semibold rounded-lg transition-colors"
                >
                  Become a Donor
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
                <Link
                  to="/recipient-registration"
                  className="inline-flex items-center px-6 py-3 bg-white hover:bg-gray-100 text-teal-900 font-semibold rounded-lg transition-colors"
                >
                  Need an Organ
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Statistics Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {stats.map(({ icon: Icon, label, value }) => (
              <div
                key={label}
                className="text-center p-6 rounded-lg bg-gradient-to-br from-teal-50 to-blue-50"
              >
                <Icon className="h-12 w-12 text-teal-600 mx-auto mb-4" />
                <div className="text-3xl font-bold text-gray-900 mb-2">{value}</div>
                <div className="text-gray-600">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Success Stories Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {successStories.map((story) => (
              <div
                key={story.id}
                className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform hover:scale-105"
              >
                <img
                  src={story.image}
                  alt={story.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{story.name}</h3>
                  <p className="text-gray-600">{story.story}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;