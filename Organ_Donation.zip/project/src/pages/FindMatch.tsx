import React, { useState, useEffect } from 'react';
import { ArrowLeft, Search, Heart, Filter, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import toast, { Toaster } from 'react-hot-toast';

interface Match {
  id: string;
  donorName: string;
  recipientName: string;
  organ: string;
  bloodType: string;
  matchScore: number;
  status: string;
}

const FindMatch = () => {
  const [matches, setMatches] = useState<Match[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState({
    organ: '',
    bloodType: '',
    minMatchScore: 0,
  });

  useEffect(() => {
    fetchMatches();
  }, []);

  const fetchMatches = async () => {
    try {
      const { data: donors } = await supabase.from('donors').select('*');
      const { data: recipients } = await supabase.from('recipients').select('*');

      // Simulate matching algorithm
      const calculatedMatches = generateMatches(donors, recipients);
      setMatches(calculatedMatches);
    } catch (error) {
      console.error('Error fetching matches:', error);
      toast.error('Failed to load matches');
    } finally {
      setIsLoading(false);
    }
  };

  const generateMatches = (donors: any[], recipients: any[]) => {
    const matches: Match[] = [];
    
    recipients?.forEach(recipient => {
      const compatibleDonors = donors?.filter(donor => 
        donor.organs.includes(recipient.organ_needed) &&
        isBloodCompatible(donor.blood_type, recipient.blood_type)
      );

      compatibleDonors?.forEach(donor => {
        const matchScore = calculateMatchScore(donor, recipient);
        matches.push({
          id: `${donor.id}-${recipient.id}`,
          donorName: donor.name,
          recipientName: recipient.name,
          organ: recipient.organ_needed,
          bloodType: `${donor.blood_type} → ${recipient.blood_type}`,
          matchScore,
          status: getMatchStatus(matchScore),
        });
      });
    });

    return matches.sort((a, b) => b.matchScore - a.matchScore);
  };

  const isBloodCompatible = (donorType: string, recipientType: string) => {
    // Simplified blood compatibility check
    const compatibility: { [key: string]: string[] } = {
      'O-': ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
      'O+': ['O+', 'A+', 'B+', 'AB+'],
      'A-': ['A-', 'A+', 'AB-', 'AB+'],
      'A+': ['A+', 'AB+'],
      'B-': ['B-', 'B+', 'AB-', 'AB+'],
      'B+': ['B+', 'AB+'],
      'AB-': ['AB-', 'AB+'],
      'AB+': ['AB+'],
    };

    return compatibility[donorType]?.includes(recipientType) || false;
  };

  const calculateMatchScore = (donor: any, recipient: any) => {
    let score = 0;
    
    // Blood type compatibility
    if (isBloodCompatible(donor.blood_type, recipient.blood_type)) {
      score += 40;
    }

    // Age factor
    const ageDiff = Math.abs(donor.age - recipient.age);
    score += Math.max(0, 20 - ageDiff);

    // Urgency level
    switch (recipient.urgency_level) {
      case 'critical': score += 40; break;
      case 'urgent': score += 30; break;
      case 'stable': score += 20; break;
      case 'planning': score += 10; break;
    }

    return Math.min(100, score);
  };

  const getMatchStatus = (score: number) => {
    if (score >= 90) return 'Excellent';
    if (score >= 75) return 'Good';
    if (score >= 60) return 'Fair';
    return 'Poor';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Excellent': return 'bg-green-100 text-green-800';
      case 'Good': return 'bg-blue-100 text-blue-800';
      case 'Fair': return 'bg-yellow-100 text-yellow-800';
      case 'Poor': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div 
      className="min-h-screen bg-cover bg-center py-12 px-4"
      style={{
        backgroundImage: 'url(https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=2000)',
        backgroundBlendMode: 'overlay',
      }}
    >
      <Toaster position="top-right" />
      <div className="max-w-7xl mx-auto">
        <Link to="/organ-matching" className="inline-flex items-center text-teal-600 hover:text-teal-700 mb-6">
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Matching
        </Link>
        
        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-xl p-8">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Find Matches</h1>
            <div className="flex items-center text-teal-600">
              <Heart className="h-6 w-6 mr-2" />
              <span className="font-semibold">AI-Powered Matching</span>
            </div>
          </div>

          {/* Filters */}
          <div className="mb-8 bg-gray-50 p-6 rounded-lg">
            <div className="flex items-center mb-4">
              <Filter className="h-5 w-5 text-gray-500 mr-2" />
              <h2 className="text-lg font-semibold">Filter Matches</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Organ Type
                </label>
                <select
                  value={filters.organ}
                  onChange={(e) => setFilters({ ...filters, organ: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                >
                  <option value="">All Organs</option>
                  <option value="kidney">Kidney</option>
                  <option value="liver">Liver</option>
                  <option value="heart">Heart</option>
                  <option value="lungs">Lungs</option>
                  <option value="pancreas">Pancreas</option>
                  <option value="corneas">Corneas</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Blood Type
                </label>
                <select
                  value={filters.bloodType}
                  onChange={(e) => setFilters({ ...filters, bloodType: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                >
                  <option value="">All Blood Types</option>
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Minimum Match Score
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={filters.minMatchScore}
                  onChange={(e) => setFilters({ ...filters, minMatchScore: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-sm text-gray-600 mt-1">
                  {filters.minMatchScore}% or higher
                </div>
              </div>
            </div>
          </div>

          {/* Matches Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Donor
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Recipient
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Organ
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Blood Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Match Score
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center">
                      Loading matches...
                    </td>
                  </tr>
                ) : matches.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center">
                      No matches found
                    </td>
                  </tr>
                ) : (
                  matches
                    .filter(match => 
                      (!filters.organ || match.organ === filters.organ) &&
                      (!filters.bloodType || match.bloodType.includes(filters.bloodType)) &&
                      match.matchScore >= filters.minMatchScore
                    )
                    .map((match) => (
                      <tr key={match.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{match.donorName}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{match.recipientName}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{match.organ}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{match.bloodType}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div
                              className="bg-teal-600 h-2.5 rounded-full"
                              style={{ width: `${match.matchScore}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-500 mt-1">
                            {match.matchScore}%
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(match.status)}`}>
                            {match.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Link
                            to={`/chat/${match.id}`}
                            className="text-teal-600 hover:text-teal-900"
                          >
                            Contact
                          </Link>
                        </td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FindMatch;