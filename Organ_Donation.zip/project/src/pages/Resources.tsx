import React from 'react';
import { ArrowLeft, Book, Video, HelpCircle, FileText, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

const Resources = () => {
  const articles = [
    {
      id: 1,
      title: 'Understanding Organ Donation',
      category: 'Education',
      readTime: '5 min read',
      image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 2,
      title: 'The Impact of Organ Donation',
      category: 'Stories',
      readTime: '7 min read',
      image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 3,
      title: 'Common Myths About Donation',
      category: 'FAQ',
      readTime: '4 min read',
      image: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&q=80&w=400',
    },
  ];

  const videos = [
    {
      id: 1,
      title: 'The Journey of Organ Donation',
      duration: '12:34',
      thumbnail: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=400',
    },
    {
      id: 2,
      title: 'Donor Stories: Making a Difference',
      duration: '8:45',
      thumbnail: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=400',
    },
  ];

  const faqs = [
    {
      question: 'Who can be an organ donor?',
      answer: 'Almost anyone can be a potential donor regardless of age, race, or medical history. The medical condition of the organs is more important than the age of the donor.',
    },
    {
      question: 'Does my religion support organ donation?',
      answer: 'Most major religions support organ donation as an act of charity and generosity. Consult with your religious advisor for specific guidance.',
    },
   
  ];

  return (
    <div 
      className="min-h-screen bg-cover bg-center py-12 px-4"
      style={{
        backgroundImage: 'url(https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=2000)',
        backgroundBlendMode: 'overlay',
      }}
    >
      <div className="max-w-6xl mx-auto">
        <Link to="/" className="inline-flex items-center text-teal-600 hover:text-teal-700 mb-6">
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </Link>
        
        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-xl p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Resources & Education</h1>
          
          {/* Educational Articles */}
          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
              <Book className="h-6 w-6 mr-2" />
              Educational Articles
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {articles.map((article) => (
                <div
                  key={article.id}
                  className="bg-white rounded-lg overflow-hidden shadow-md transition-transform hover:scale-105"
                >
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-teal-600">{article.category}</span>
                      <span className="text-sm text-gray-500">{article.readTime}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{article.title}</h3>
                    <button className="text-teal-600 hover:text-teal-700 text-sm font-medium">
                      Read More
                      <ExternalLink className="h-4 w-4 inline ml-1" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
          
          {/* Video Resources */}
          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
              <Video className="h-6 w-6 mr-2" />
              Video Resources
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {videos.map((video) => (
                <div
                  key={video.id}
                  className="bg-white rounded-lg overflow-hidden shadow-md"
                >
                  <div className="relative">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-64 object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors">
                        <div className="w-0 h-0 border-t-8 border-b-8 border-l-12 border-transparent border-l-teal-600 ml-1" />
                      </div>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-sm">
                      {video.duration}
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="text-lg font-semibold text-gray-900">{video.title}</h3>
                  </div>
                </div>
              ))}
            </div>
          </section>
          
          {/* FAQs */}
          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
              <HelpCircle className="h-6 w-6 mr-2" />
              Frequently Asked Questions
            </h2>
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <div
                  key={index}
                  className="bg-white rounded-lg p-6 shadow-md"
                >
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{faq.question}</h3>
                  <p className="text-gray-600">{faq.answer}</p>
                </div>
              ))}
            </div>
          </section>
          
          {/* Additional Resources */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
              <FileText className="h-6 w-6 mr-2" />
              Additional Resources
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-teal-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-teal-900 mb-4">Download Information Pack</h3>
                <p className="text-teal-700 mb-4">
                  Get comprehensive information about organ donation, including guidelines,
                  procedures, and legal requirements.
                </p>
                <button className="inline-flex items-center text-teal-600 hover:text-teal-700 font-medium">
                  Download PDF
                  <ExternalLink className="h-4 w-4 ml-1" />
                </button>
              </div>
              <div className="bg-blue-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-blue-900 mb-4">Research Papers</h3>
                <p className="text-blue-700 mb-4">
                  Access the latest research papers and studies about organ donation
                  and transplantation.
                </p>
                <button className="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium">
                  View Library
                  <ExternalLink className="h-4 w-4 ml-1" />
                </button>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Resources;