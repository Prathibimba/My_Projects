import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send, Phone, Camera as VideoCamera, Paperclip, User } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import toast, { Toaster } from 'react-hot-toast';

interface Message {
  id: number;
  sender: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

const Chat = () => {
  const { matchId } = useParams();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [recipient, setRecipient] = useState({ name: '', avatar: '' });
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  useEffect(() => {
    loadInitialData();
    const messageInterval = setInterval(fetchNewMessages, 3000);
    return () => clearInterval(messageInterval);
  }, [matchId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadInitialData = async () => {
    try {
      // In a real app, fetch actual messages from Supabase
      setMessages([
        {
          id: 1,
          sender: 'system',
          content: 'Chat session started',
          timestamp: new Date().toISOString(),
          isRead: true,
        },
        {
          id: 2,
          sender: 'recipient',
          content: 'Hello! I saw we have a potential match.',
          timestamp: new Date().toISOString(),
          isRead: true,
        },
      ]);
      
      setRecipient({
        name: 'Dr. Sarah Johnson',
        avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=100',
      });
    } catch (error) {
      console.error('Error loading chat:', error);
      toast.error('Failed to load chat');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchNewMessages = async () => {
    // In a real app, fetch new messages from Supabase
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      const message = {
        id: messages.length + 1,
        sender: 'user',
        content: newMessage,
        timestamp: new Date().toISOString(),
        isRead: false,
      };

      setMessages(prev => [...prev, message]);
      setNewMessage('');

      // Simulate recipient response
      setTimeout(() => {
        const response = {
          id: messages.length + 2,
          sender: 'recipient',
          content: "Thank you for your message. I will review the details and get back to you soon.",
          timestamp: new Date().toISOString(),
          isRead: false,
        };
        setMessages(prev => [...prev, response]);
      }, 1000);
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" />
      
      {/* Chat Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link to="/find-match" className="text-gray-500 hover:text-gray-700">
                <ArrowLeft className="h-6 w-6" />
              </Link>
              <div className="flex items-center ml-4">
                <img
                  src={recipient.avatar}
                  alt={recipient.name}
                  className="h-8 w-8 rounded-full"
                />
                <div className="ml-3">
                  <div className="text-sm font-medium text-gray-900">{recipient.name}</div>
                  <div className="text-xs text-gray-500">Match ID: {matchId}</div>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-gray-500 hover:text-gray-700">
                <Phone className="h-5 w-5" />
              </button>
              <button className="text-gray-500 hover:text-gray-700">
                <VideoCamera className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-lg h-[calc(100vh-16rem)]">
          <div className="h-full flex flex-col">
            <div className="flex-1 overflow-y-auto p-4">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-gray-500">Loading messages...</div>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${
                        message.sender === 'user' ? 'justify-end' : 'justify-start'
                      }`}
                    >
                      {message.sender === 'system' ? (
                        <div className="bg-gray-100 rounded-lg px-4 py-2 max-w-sm">
                          <p className="text-sm text-gray-500">{message.content}</p>
                        </div>
                      ) : (
                        <div className={`flex ${message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                          <div className="flex-shrink-0">
                            {message.sender === 'recipient' ? (
                              <img
                                src={recipient.avatar}
                                alt={recipient.name}
                                className="h-8 w-8 rounded-full"
                              />
                            ) : (
                              <div className="h-8 w-8 rounded-full bg-teal-500 flex items-center justify-center">
                                <User className="h-5 w-5 text-white" />
                              </div>
                            )}
                          </div>
                          <div
                            className={`mx-2 ${
                              message.sender === 'user'
                                ? 'bg-teal-500 text-white'
                                : 'bg-gray-100 text-gray-900'
                            } rounded-lg px-4 py-2 max-w-sm`}
                          >
                            <p className="text-sm">{message.content}</p>
                            <p className="text-xs mt-1 opacity-75">
                              {formatTime(message.timestamp)}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </div>

            {/* Message Input */}
            <div className="border-t p-4">
              <form onSubmit={handleSendMessage} className="flex items-center space-x-4">
                <button
                  type="button"
                  className="text-gray-500 hover:text-gray-700"
                >
                  <Paperclip className="h-5 w-5" />
                </button>
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1 border-0 focus:ring-0 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!newMessage.trim()}
                  className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 ${
                    !newMessage.trim() ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;